package com.mockito.demo;

public interface ExternalApi {
    String getData();
}
