package com.cognizant.spring_learn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cognizant.spring_learn.Country2;
import com.cognizant.spring_learn.service.CountryService2;

@RestController
public class CountryController2 {

	@Autowired
	private CountryService2 countryService2;

	@GetMapping("/country2/{code}")
	public Country2 getCountry(@PathVariable String code) {
		return countryService2.getCountry(code);
	}
}
