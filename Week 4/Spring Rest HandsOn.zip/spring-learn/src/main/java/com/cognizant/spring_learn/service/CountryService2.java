package com.cognizant.spring_learn.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.spring_learn.Country2;

@Service
public class CountryService2 {

	public Country2 getCountry(String code) {
		ApplicationContext context = new ClassPathXmlApplicationContext("country2.xml");
		List<Country2> countryList = (List<Country2>) context.getBean("countryList2");

		return countryList.stream()
				.filter(c -> c.getCode().equalsIgnoreCase(code))
				.findFirst()
				.orElse(null);
	}
}
